<?php 
    $views = "edit_slider";
    include ("template.php");

?>